
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://xfousvlrhinlvrpryscy.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhmb3VzdmxyaGlubHZycHJ5c2N5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI2MTg0NDYsImV4cCI6MjA3ODE5NDQ0Nn0.ah4qi9NtkUAyxrcOMPQi9T6pmgEW6ZMHcjhA9tNI8s0';


let supabaseInstance: SupabaseClient;
let supabaseAnonInstance: SupabaseClient;
let initializationError: Error | null = null;


try {
  // Add checks for missing credentials.
  if (!supabaseUrl) {
    throw new Error("A variável de ambiente SUPABASE_URL não foi encontrada.");
  }
  if (!supabaseKey) {
      throw new Error("A variável de ambiente SUPABASE_ANON_KEY não foi encontrada.");
  }

  // This is the standard client that will manage user sessions for authenticated actions.
  supabaseInstance = createClient(supabaseUrl, supabaseKey);
  
  // This is a completely stateless client for fetching public data anonymously.
  // It's configured to never persist sessions, preventing it from using a logged-in user's token.
  supabaseAnonInstance = createClient(supabaseUrl, supabaseKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    }
  });
  

} catch (error: any) {
  initializationError = error;
  // This dummy client is a fallback to prevent the app from crashing entirely
  // if initialization fails. It will not be functional.
  if (!supabaseInstance) {
    const dummyClient = {
      from: () => { throw initializationError; },
      auth: {
          getSession: () => Promise.resolve({ data: { session: null }, error: initializationError }),
          onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
      },
      // Mock other methods as needed to prevent crashes
    } as any;
    supabaseInstance = dummyClient;
    supabaseAnonInstance = dummyClient;
  }
}

export const supabase = supabaseInstance;
export const supabaseAnon = supabaseAnonInstance;
export const SUPABASE_URL = supabaseUrl;
export const SUPABASE_ANON_KEY = supabaseKey;

export const getInitializationError = () => initializationError;

// Centralized error handler
export const handleSupabaseError = ({ error, customMessage, tableName }: { error: any, customMessage: string, tableName?: string }) => {
    if (error) {
        console.error(customMessage, error);
        let enhancedMessage = `${customMessage} (Supabase: ${error.message || String(error)})`;

        // Combine relevant parts of the error for a more robust search
        const fullErrorMessageLower = `${error.message || ''} ${error.details || ''} ${error.hint || ''}`.toLowerCase();

        // Check for 'column does not exist' error (PostgreSQL error code 42703 for undefined_column)
        // If it's the promotions table, we proactively list all common missing columns.
        if (error.code === '42703' && tableName === 'promotions') {
            let columnFixMessage = `Erro de Banco de Dados: Algumas colunas essenciais estão faltando na sua tabela 'promotions'. Para que as promoções e a gestão de marketing funcionem corretamente, por favor, execute os seguintes comandos SQL no seu Supabase:\n\n`;
            let sqlCommands = '';

            // Assume these are always needed if a 42703 error occurs on 'promotions'
            sqlCommands += `ALTER TABLE public.promotions ADD COLUMN startDate TIMESTAMP WITH TIME ZONE;\n`;
            sqlCommands += `ALTER TABLE public.promotions ADD COLUMN endDate TIMESTAMP WITH TIME ZONE;\n`;
            sqlCommands += `ALTER TABLE public.promotions ADD COLUMN is_featured BOOLEAN DEFAULT FALSE;\n`;
            
            if (sqlCommands) { // Only append if there are actual commands
                columnFixMessage += sqlCommands;
                columnFixMessage += `\nCaso algumas colunas já existam, você pode ignorar os erros 'column already exists'.`;
                enhancedMessage = `Problema com as Promoções em Destaque: ${columnFixMessage}`; // Simplified message, remove redundant customMessage
            }
        } else if (error.code === '42701' && tableName === 'promotions' && fullErrorMessageLower.includes('column "') && fullErrorMessageLower.includes('" of relation "promotions" already exists')) {
            // This specifically addresses any "column already exists" error for the `promotions` table.
            // Log a message and return, indicating that this specific issue is not critical and the operation should proceed.
            console.log(`[GuaraFood Info] Coluna já existe na tabela 'promotions'. Isso não é um erro crítico. Detalhes: ${error.message}`, error);
            return; // Important: return here to not throw an error from handleSupabaseError
        } else if (error.code === 'PGRST116') { // No rows found for .single()
            // This is often not a "real" error, so we might not want to throw
            console.warn("Supabase warning: .single() query returned no rows.");
            return; // Important: return here to not throw for PGRST116
        }
        
        throw new Error(enhancedMessage);
    }
};