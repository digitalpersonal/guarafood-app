import React, { useState, useEffect, useCallback } from 'react';
import type { Promotion } from '../types';
import { fetchAllPromotions, updatePromotionFeaturedStatus } from '../services/geminiService';
import Spinner from './Spinner';
import { useNotification } from '../hooks/useNotification';

const MarketingManagement: React.FC = () => {
    const [promotions, setPromotions] = useState<Promotion[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { addToast } = useNotification();

    const loadPromotions = useCallback(async () => {
        try {
            setIsLoading(true);
            const data = await fetchAllPromotions();
            setPromotions(data);
            setError(null);
        } catch (err) {
            setError('Falha ao carregar promoções.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadPromotions();
    }, [loadPromotions]);

    const handleToggleFeatured = async (promo: Promotion) => {
        const newFeaturedStatus = !promo.is_featured;
        
        // Optimistic update
        setPromotions(prev => prev.map(p => p.id === promo.id ? { ...p, is_featured: newFeaturedStatus } : p));
        
        try {
            await updatePromotionFeaturedStatus(promo.id, newFeaturedStatus);
            addToast({ message: `Promoção "${promo.name}" ${newFeaturedStatus ? 'destacada' : 'não destacada'}.`, type: 'success' });
        } catch (err) {
            addToast({ message: 'Falha ao atualizar status.', type: 'error' });
            // Revert on failure
            setPromotions(prev => prev.map(p => p.id === promo.id ? { ...p, is_featured: !newFeaturedStatus } : p));
        }
    };

    if (isLoading) return <Spinner message="Carregando promoções..." />;
    if (error) return <p className="text-center text-red-500">{error}</p>;

    return (
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-bold text-gray-800 mb-1">Destaque de Promoções na Home</h2>
            <p className="text-sm text-gray-500 mb-4">Selecione quais promoções ativas devem aparecer no banner da página inicial para todos os clientes.</p>
            <div className="overflow-x-auto">
                <table className="w-full text-sm text-left text-gray-600">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" className="px-6 py-3">Promoção</th>
                            <th scope="col" className="px-6 py-3">Restaurante</th>
                            <th scope="col" className="px-6 py-3 text-center">Destaque na Home</th>
                        </tr>
                    </thead>
                    <tbody>
                        {promotions.map(promo => (
                            <tr key={promo.id} className="bg-white border-b hover:bg-gray-50">
                                <td className="px-6 py-4 font-semibold text-gray-900">
                                    {promo.name}
                                    <p className="font-normal text-xs text-gray-500">{promo.description}</p>
                                </td>
                                <td className="px-6 py-4">{promo.restaurant?.name || 'N/A'}</td>
                                <td className="px-6 py-4 text-center">
                                     <label htmlFor={`featured-toggle-${promo.id}`} className="flex justify-center items-center cursor-pointer">
                                        <div className="relative">
                                            <input 
                                                id={`featured-toggle-${promo.id}`} 
                                                type="checkbox" 
                                                className="sr-only peer" 
                                                checked={!!promo.is_featured} 
                                                onChange={() => handleToggleFeatured(promo)} 
                                            />
                                            <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                                        </div>
                                    </label>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {promotions.length === 0 && <p className="text-center text-gray-500 col-span-full py-8">Nenhuma promoção encontrada.</p>}
            </div>
        </div>
    );
};

export default MarketingManagement;