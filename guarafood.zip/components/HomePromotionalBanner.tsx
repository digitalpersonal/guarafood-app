import React, { useState, useEffect } from 'react';
import type { Promotion } from '../types';
import { generateImage } from '../services/geminiService';
import Spinner from './Spinner';

interface HomePromotionalBannerProps {
  promotion: Promotion;
}

const TagIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 003 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 005.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 009.568 3z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6z" />
  </svg>
);


const HomePromotionalBanner: React.FC<HomePromotionalBannerProps> = ({ promotion }) => {
    const [backgroundImage, setBackgroundImage] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchImage = async () => {
            setIsLoading(true);
            setError(null);
            setBackgroundImage(null); // Clear previous image
            
            try {
                const prompt = `A vibrant and appealing food photography image featuring '${promotion.name}' with a focus on '${promotion.description}' in an appetizing style. Ensure high resolution and professional quality.`;
                const imageUrl = await generateImage(prompt);
                setBackgroundImage(imageUrl);
            } catch (err: any) {
                console.error("Failed to generate promotional image:", err);
                setError("Failed to load dynamic image.");
                // Fallback to a solid background if image generation fails
                setBackgroundImage(null); 
            } finally {
                setIsLoading(false);
            }
        };

        fetchImage();
    }, [promotion]);

  return (
    <div 
        className="relative bg-gradient-to-r from-red-600 to-orange-500 text-white rounded-lg shadow-lg p-4 my-4 mx-4 flex items-center space-x-4 overflow-hidden min-h-[150px]"
        style={{ backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined, backgroundSize: 'cover', backgroundPosition: 'center' }}
    >
        {isLoading && (
            <div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center">
                <Spinner message="Gerando imagem para promoção..." />
            </div>
        )}
        {error && !isLoading && (
            <div className="absolute inset-0 bg-red-600 bg-opacity-80 flex items-center justify-center p-4">
                <p className="text-white text-center text-sm">Erro ao carregar imagem: {error}</p>
            </div>
        )}
        {!isLoading && (
            <div className="relative z-10 flex items-center space-x-4 bg-black bg-opacity-30 p-3 rounded-lg flex-grow min-w-0">
                <div className="flex-shrink-0">
                    <TagIcon className="w-10 h-10 transform -rotate-12" />
                </div>
                <div className="flex-grow">
                    <h3 className="font-extrabold text-lg tracking-wide">{promotion.name}</h3>
                    <p className="text-sm opacity-90">{promotion.description}</p>
                </div>
            </div>
        )}
    </div>
  );
};

export default HomePromotionalBanner;