
# 🚀 Checklist de Produção: GuaraFood (Windows 10 Edition)

Seu site já está no Vercel (Frontend), mas para o Pix Automático funcionar, o **Backend (Supabase Edge Functions)** precisa ser enviado para a nuvem.

## 1. Instalação do Ambiente (Apenas na 1ª vez)
No Windows 10, abra o **PowerShell** ou **Prompt de Comando (CMD)** como Administrador.

1. **Instalar Node.js:** Baixe e instale a versão LTS do site oficial [nodejs.org](https://nodejs.org).
2. **Verificar instalação:**
   ```bash
   node -v
   # Deve aparecer algo como v20.x.x
   ```
3. **Instalar Supabase CLI:**
   ```bash
   npm install -g supabase
   ```

## 2. Login no Supabase
1. No terminal, digite:
   ```bash
   npx supabase login
   ```
2. O navegador abrirá. Clique em **"Confirm"**.
3. Volte ao terminal, deve aparecer: `You are now logged in`.

## 3. Deploy das Funções (Fazer o Pix Funcionar)
Rode estes comandos um por um na pasta do seu projeto.
*(Substitua `xfousvlrhinlvrpryscy` pelo ID do seu projeto se for diferente)*

1. **Função de Criar Pagamento:**
   ```bash
   npx supabase functions deploy create-payment --project-ref xfousvlrhinlvrpryscy --no-verify-jwt
   ```
2. **Função de Confirmação (Webhook):**
   ```bash
   npx supabase functions deploy payment-webhook --project-ref xfousvlrhinlvrpryscy --no-verify-jwt
   ```
3. **Função de Criar Restaurante (Admin):**
   ```bash
   npx supabase functions deploy create-restaurant-with-user --project-ref xfousvlrhinlvrpryscy --no-verify-jwt
   ```

## 4. Configurar Segredos (Conectar Funções ao Banco)
As funções precisam saber onde fica o banco de dados.

```bash
npx supabase secrets set SUPABASE_URL=https://xfousvlrhinlvrpryscy.supabase.co --project-ref xfousvlrhinlvrpryscy
```

```bash
npx supabase secrets set SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhmb3VzdmxyaGlubHZycHJ5c2N5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI2MTg0NDYsImV4cCI6MjA3ODE5NDQ0Nn0.ah4qi9NtkUAyxrcOMPQi9T6pmgEW6ZMHcjhA9tNI8s0 --project-ref xfousvlrhinlvrpryscy
```

## 5. Configuração Final no Painel
1. Acesse o **Painel do Lojista** no seu site (Vercel).
2. Vá em **Configurações**.
3. Coloque o **Access Token** do Mercado Pago (Produção).
4. Copie a **URL do Webhook** que aparece lá.
5. Vá no site do Mercado Pago -> Suas Integrações -> Webhooks e cole essa URL.

**Pronto!** Agora, quando um cliente pagar o Pix:
1. O Mercado Pago avisa o Supabase.
2. O Supabase avisa seu painel.
3. O painel **Toca a Sirene** e **Imprime o Pedido** automaticamente.
